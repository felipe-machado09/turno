<?php

return [
    'site_title' => 'BNB Bank',
];
