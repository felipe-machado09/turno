<template>
  <ul class="nav nav-mobile-menu">
    <top-navbar-languages />
  </ul>
</template>

<script>
export default {}
</script>
